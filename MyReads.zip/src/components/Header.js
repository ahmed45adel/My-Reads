import React from "react";

const Header = () => {
    return (
        < div className="list-books-title" >
            <h1>MyReads</h1>
        </div >
    )

}
export default Header;